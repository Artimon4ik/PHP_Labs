<?php
/*
echo "Привет, мир!<br />";

 echo "Hello, World with echo!<br />";

print "Hello, World with print!<br />";
*/
$days = 288;
$message = "Все возвращаются на работу!";


//Конкатинация
echo  "Число дней" . $days ." <br />";
echo "Сообщение работникам". $message . "<br />";

//Кавычки
echo "Число дней: $days<br />";
echo "Сообщение: $message<br />";

?>